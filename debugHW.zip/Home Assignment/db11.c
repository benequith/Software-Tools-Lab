#include<stdio.h>

int main(){
    int i;
    int *p;
    *p = 25;
   
    printf("i is %d and *p is %d",i,*p);
}
