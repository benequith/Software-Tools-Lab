#include <stdio.h>
#include <stdlib.h>

int isquare(short int x){
    return x*x;
}

int main(){
    int i = 1000000,j;
    
	j = isquare(i);
    printf("%d squared = %d",i,j);
    
	return 0;
}
/*Program is supposed to print the value of i^2, i.e: 1000000^2
Execute the program and find the reason for unexpected result using GDB*/