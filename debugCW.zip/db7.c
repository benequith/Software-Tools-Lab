#include <stdio.h>
#include <stdlib.h>

int main(){
    short int x = 1,i;
    
	for(i=1;i<=128;i=i*2)
    {
        x <<=i; // HINT : This  is the bit wise shift short-hand assignment operator
        printf("\nValue of x is %d after shifting by %d",x,i);
        x = 1;
    }
	
	return 0;
}
/* Program is supposed to print the powers of 2 table, starting from 2^0 through to 2^128
Execute the program and find the reason for unexpected result using GDB*/