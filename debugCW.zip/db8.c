#include <stdio.h>
#include <stdlib.h>

int main(){
    int array[5],i;
    
	for(i=0;i<=5;i++) {
      array[i] += 1;
		 printf("\nvalue of array[%d] is %d",i,array[i]);
    }
    
	return 0;
}
/* Program is suppsed to fill up array as 1 2 3 4 5
Execute the program and find the reason for unexpected result using GDB*/